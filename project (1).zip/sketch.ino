void setup() {pinMode(13, OUTPUT); // LED merah
  pinMode(12, OUTPUT); // LED kuning
  pinMode(11, OUTPUT); // LED hijau
  // put your setup code here, to run once:

}

void loop() {
  // put your madigitalWrite(13, HIGH);
  digitalWrite(12, HIGH);
  digitalWrite(11, HIGHin code here, to run repeatedly:

}
